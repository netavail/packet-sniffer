
from scapy.all import sniff
from flask import Flask, Response
from flask_cors import CORS
import json
import threading

app = Flask(__name__)
CORS(app)

packet_buffer = []

def process_packet(packet):
    try:
        pkt = {
            "src": packet[0][1].src if packet.haslayer(1) else "N/A",
            "dst": packet[0][1].dst if packet.haslayer(1) else "N/A",
            "proto": packet.name,
            "summary": packet.summary()
        }
        packet_buffer.append(pkt)
        if len(packet_buffer) > 50:
            packet_buffer.pop(0)
    except Exception as e:
        print("Error:", e)

def start_sniffing():
    sniff(prn=process_packet, store=0)

@app.route("/packets")
def get_packets():
    return Response(json.dumps(packet_buffer), mimetype='application/json')

if __name__ == "__main__":
    thread = threading.Thread(target=start_sniffing)
    thread.daemon = True
    thread.start()
    app.run(host="0.0.0.0", port=5000)
